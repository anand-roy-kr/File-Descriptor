import java.util.List;
public class Consumers {



        private List<Consumer> consumers;
        public List<Consumer> getConsumers() {
            return consumers;
        }

        public void setConsumers(List<Consumer> consumers) {
            this.consumers = consumers;
        }
    }
